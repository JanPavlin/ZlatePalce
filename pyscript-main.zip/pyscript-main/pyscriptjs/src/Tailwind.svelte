<style global lang="postcss">
    @tailwind base;
    @tailwind components;
    @tailwind utilities;
</style>
